% ------------------------------------------------
% ---------- Armijo Schrittweitensuche  ----------
% ------------------------------------------------
%
% ------------------------------------------------
%  
%  INPUT: f,fx,gfx,x,s,beta,gamma,maxit
%  OUTPUT: Schrittweite sigma
% ------------------------------------------------

function [sigma] = Armijo(f,fx,gfx,x,s,beta,gamma,maxit)

% skalierte Richtungsableitung in Richtung s
...

% Startwert fuer sigma
sigma = 1.0;

% Schleife ueber die Armijo Schritte
for it = 1:maxit
    
    % Funktionswert an dem Kandidaten fuer die neue Iterierte
    ...
    
    % falls Armijo-Bedingung erfuellt
    if ...
        break;
    % falls Armijo-Bedingung nicht erfuellt
    else
        ...
    end
end

% Warnung falls maxit erreicht und kein Abstieg erzielt
if ...
    warning('Function Armijo was unable to find admissable step size')
end

end