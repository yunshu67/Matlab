% ------------------------------------------------
% ------------- Gradientenverfahren  -------------
% ------------------------------------------------
%
% ------------------------------------------------
%  
%  INPUT: f,x0,tol,maxit
%  OUTPUT: x, fx, steps
% ------------------------------------------------

function [x, fx, steps] = GradientenVerf(f,x0,tol,maxit)

% Armijo Parameter
Armijo_beta = 0.5;
Armijo_gamma = 1e-4;
Armijo_maxit = 20;

% Initialisiere die Iterierte x
x = ...

% Plotten der Niveaumengen
...

% Schleife ueber die Iterationen
for steps = ...
   
    % Berechne aktuellen Funktionswert und Gradienten
    ...
    
    % Checke Abbruchkriterium
    if ...
        break;
    end
    
    % Definiere Suchrichtung
    ...
    
    % Bestimme Schrittweite mit Armijo-Backtracking
    ...
    
    % Update der Iterierten
    ...
        
    % Plotten der Iterierten
    ...
end

% Warnung, falls Abbruchkriterium nicht erreicht. 
if (norm(gfx,2)>=tol)
    warning('Function GradientenVerf was unable to reach the desired tolerance')
end

% Definition des Rueckgabewertes fx
fx = ...

end